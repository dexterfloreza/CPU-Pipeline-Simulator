#pragma once
struct MEMStage{
    uint32_t value=0;
    void execute(){}
};
