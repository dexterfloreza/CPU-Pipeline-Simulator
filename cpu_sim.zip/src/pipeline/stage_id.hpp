#pragma once
#include "../isa/rv32i.hpp"
DecodedInstr decode(uint32_t);
